export default function CreateTodo() {
    return (
        <div>
            <input type = "text" placeholder = "title"></input> <br/>
            <input type = "text" placeholder = "description"></input>
            <button>Add a todo</button>
        </div>
    );
}